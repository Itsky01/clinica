<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Http\Request;
use App\Models\Profesional;
use App\Models\Dias;
use App\Models\Horarios_de_trabajo;
use App\Models\Fecha as FechaModel;
use Illuminate\Support\Facades\DB;
use App\Models\Fechas_estudio;

class Cargarfechas extends Component
{  
   public $diaprof=null,$nombredia=null,$d_id,$seleccionar=true,$diatrabajo,$contardias=null,$contarfechas=null,$selectedprofesional=null,$fechas=null,$selecteddia=null,$startdate=null,$enddate=null; 
  public $mifecha,$prof_id,$eligefecha,$listarfecha=null,$fechasprofesional,$deletefecha='',$idurl,$idprofes,$newid,$prof,$valor; 

  protected $listeners = ['mifecha' => '$store'];
   public function render(){
    
    return view ('livewire.cargarfechas',['profesionales'=> Profesional::all()
        
   ]);
}

public function mount($id){
 $this->contarfechas = FechaModel::join('dias' ,'fechas.dias_id','=', 'dias.d_id')
     ->where('profesionales_id',$id)->count(); // contar fechas de trabajo cargadas
  //  $this->reset(['startdate']);
    $this->valor=$id;
    $this->listarfecha = FechaModel::join('dias' ,'fechas.dias_id','=', 'dias.d_id')
    ->where('profesionales_id',$id)->get(); // listar fechas cargadas
  
    //$this->valor =session()->get('id');


    $this->diaprof = Horarios_de_trabajo::join('dias' ,'horarios_de_trabajos.dias_id','=', 'dias.d_id')
     ->where('profesionales_id',$id)->distinct()->get(); // listar dias de trabajo

   



 //public function updatedSelectedprofesional($prof_id){
     

  //  $this->reset(['diaprof']);
  /*  $this->diaprof = Horarios_de_trabajo::join('dias' ,'horarios_de_trabajos.dias_id','=', 'dias.d_id')
     ->where('profesionales_id',$prof_id)->distinct()->get(); // listar dias de trabajo

   $this->listarfecha = FechaModel::join('dias' ,'fechas.dias_id','=', 'dias.d_id')
     ->where('profesionales_id',$prof_id)->get(); // listar fechas cargadas
    
    $this->contardias = Horarios_de_trabajo::join('dias','horarios_de_trabajos.dias_id','=', 'dias.d_id')
      ->where('profesionales_id',$prof_id)->count(); // contar dias de trabajo
     $this->reset(['startdate']);

     $this->contarfechas = FechaModel::join('dias' ,'fechas.dias_id','=', 'dias.d_id')
     ->where('profesionales_id',$prof_id)->count(); // contar fechas de trabajo cargadas
    $this->reset(['startdate']); */
     
  }

  

   public function updatedSelecteddia($d_id){
      if ($d_id !="0") {
      
      
     
      $this->diaprof=Dias::where('d_id',$d_id)->get();  
            
    if($d_id== "1") {
        $diatrabajo="Monday";
        
    }else{


        if($d_id== "2") {
            $diatrabajo="Thursday";
            
                }else{
            if($d_id== "3") {
                $diatrabajo="Wednesday";
                     
                
            }else{
                if($d_id== "4") {
                    $diatrabajo="Thursday";
                    
                }else{
                    if($d_id== "5") {
                        $diatrabajo="Friday";
                    }}}}}


   $this->startdate=strtotime($diatrabajo); //dia de comienzo
    
    $this->enddate=strtotime("+6 weeks ", $this->startdate); // limite de fechas:6 semanas  de anticipacion desde ese dia
   
      /*  $this->divfechas = Fecha::where('profesionales_id',$prof_id)->count();
   
    $this->horarios=null;
    $this->btncontinuar=false;  */ 
     // return view('layouts.admin.crearTurno.fechas_horarios', compact('fecha'));
  
  
}else{
 
 $this->startdate=null;
 $this->enddate=null; 
   // $this->seleccionar=false;
 $this->reset(['diaprof']);
$this->diaprof=Dias::where('d_id',$d_id)->get();
   // $this->reset(['startdate']);
   $this->selectedprofesional=null;
 
   
  
}}




public function store($valor){
        
    $pregunta=DB::table('fechas') // para saber si fecha recibida ya existe en tabla
    ->select('fecha')
    ->where('fecha','=',$this->mifecha)
    ->where('profesionales_id','=',$this->valor)
    ->get();
    if(!empty($pregunta)) {
                  
     FechaModel::create([
    'fecha' => $this->mifecha,
    'profesionales_id' => $this->valor, // id prof 
    'dias_id' => $this->selecteddia, // id dia

   //       return redirect('/tipo_turno')->with('exito_estudio','here your success message');; 
]);      
    }else{

 // fecha ya existe
         
        return redirect()->route('fechas')->with('invalidfecha','here your success message');
      
     
    }}

 

public function deletefecha ($f_id){
    $this->deletefecha = $f_id;

   
}

public function idprofes (){

//  $this->idurl= Profesional::where('prof_id',$id)->first();  // listar fechas cargadas

}
public function delete($valor){
  
   FechaModel::destroy($this->deletefecha);
     $this->emit('postUpdated');
       
      session()->flash('message', 'Post successfully updated.');
     // $id = $request->input('id');
      return redirect()->to(route('cargafechas', ['id' =>$valor]));
  //  return view ('livewire.cargarfechas');
}



}
