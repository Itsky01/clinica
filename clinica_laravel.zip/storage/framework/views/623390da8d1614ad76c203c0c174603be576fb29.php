
 
<div class="p-5 ">
  
  <div class="row d-flex justify-content-center ">
    <div class="col-md-7">
      <div class="card p-4 py-4 shadow">
    <h2 class="p-3 bg-info text-white text-center rounded shadow">Nuevo usuario</h2>
   
   
    <form action="" method="post" >
        <?php echo csrf_field(); ?>
       
    <div class="mt-2">
    <label for="exampleFormControlInput1" class="form-label">Apellido</label>
    <input type="text" class="form-control" name="apellido"  placeholder="Apellido" value="<?php echo e(old('apellido')); ?>">
    <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div >
<div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">Nombre</label></div>
    <input type="text" class="form-control" name="name" placeholder="Nombre" value="<?php echo e(old('name')); ?>">
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div >
  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">documento</label></div>
    <input type="number" class="form-control" name="documento" placeholder="Documento" value="<?php echo e(old('documento')); ?>">
    <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
  </div>
  
  

  <div >
  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">domicilio</label></div>
    <input type="text" class="form-control"  name="domicilio" placeholder="domicilio" value="<?php echo e(old('domicilio')); ?>">
    <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
  </div>
  
  <div >
  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">telefono</label></div>
    <input type="number" class="form-control"  name="telefono" placeholder="telefono" value="<?php echo e(old('telefono')); ?>">
  
    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  
  <div >
  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">Fecha de nacimiento</label></div>
    <input type="date" class="form-control"  name="fecha" placeholder="fecha de nacimiento" value="<?php echo e(old('fecha')); ?>">
  
    <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
  </div> 

  <div >
  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">password</label></div>
    <input type="password" class="form-control"  name="password" >
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div >
    <div class="mt-3">
      <label for="exampleFormControlInput1" class="form-label">repetir password</label></div>
      <input type="password" class="form-control"  name="password_confirmation" >
      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  <div >
  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">Email address</label>
    <input type="email" class="form-control" name="email" placeholder="name@example.com" value="<?php echo e(old('email')); ?>">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </div></div>

<div class="d-grid gap-2 mt-3">
  <button type="submit" class="btn btn-primary">Crear</button>
  <a href ="<?php echo e(route('dash_admin')); ?>"  class="btn btn-danger" >VOLVER</a> 
 </div>

</form>

      </div>
    </div>
</div>

</div>

<?php echo $__env->make('layouts.admin.pacientes.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\pacientes\crear.blade.php ENDPATH**/ ?>