
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <!-- seccion para pantalla principal de profesionales: titulo y contenido -->
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-center">
            <?php echo e(__('profesionales')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                    Nuevo
                  </button>

                 <table class="table table-hover">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellido</th>
                        <th scope="col">Documento</th>

                        <th scope="col">telefono</th>
                       
                         <th scope="col">email</th>
<th></th>
<th></th>


                      </tr>
                    </thead>
                    <tbody>
 <?php $__currentLoopData = $profesion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th><?php echo e($dato->id); ?></th>
<th><?php echo e($dato->prof_nombre); ?></th>
<th><?php echo e($dato->prof_apellido); ?></th>
<th><?php echo e($dato->prof_dni); ?></th>
<th><?php echo e($dato->prof_telefono); ?></th>
<th><?php echo e($dato->prof_domicilio); ?></th>
<th><?php echo e($dato->prof_email); ?></th>

<form action="" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<td><a href =""  class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">EDITAR</a>    </td>
<td><button type="submit" class="btn btn-danger">borrar</button></td>

</form>
</tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
                  
                  </table>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\pacientes\index.blade.php ENDPATH**/ ?>