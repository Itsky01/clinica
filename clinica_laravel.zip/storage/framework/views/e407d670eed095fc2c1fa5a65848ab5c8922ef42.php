

<div class="p-5 ">
  
  <div class="row d-flex justify-content-center ">
    <div class="col-md-7">
      <div class="card p-4 py-4 shadow">
   
   
   
   
    <h2 class="p-2 bg-info text-white text-center shadow">Editar profesionales</h2>
  
    <form action="<?php echo e(route('edicion', $pr->prof_id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
          
        
        <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">Apellido</label>
    <input type="text" class="form-control" id="apellido" name="apellido" value="<?php echo e($pr->prof_apellido); ?>" placeholder="Apellido">
   <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div >
  
rt
<div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">Nombre</label>
    <input type="text" value="<?php echo e($pr->prof_nombre); ?>" class="form-control" name="nombre" placeholder="Nombre">
  </div>
  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>




<div >
  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">especialidad</label>
  
  </div>
  <div class="mt-3">
   
    <input type="text" value="<?php echo e($pr->esp_nombre); ?>" class="form-control" name="esp" id="esp" readonly>
 <input type="hidden" value="<?php echo e($pr->esp_id); ?>" name="id_esp" id="id_esp"> 
  </div>
<div class="form-group mt-2">

<select class="form-select" aria-label="Default select example" name="especialidad" id="especialidad" onchange="ShowSelected();">
  <option selected disabled>Elija una especialidad</option>
  <?php $__currentLoopData = $esp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($dato->esp_id); ?>"><?php echo e($dato->esp_nombre); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div> 


    <?php $__errorArgs = ['especialidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

<div >
  

  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">documento</label>
  </div>  <input type="number" class="form-control" value="<?php echo e($pr->prof_dni); ?>" name="documento" placeholder="Documento">
 
 
    <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div >
  

  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">domicilio</label>
  </div>  <input type="text" class="form-control"  value="<?php echo e($pr->prof_domicilio); ?>" name="domicilio" placeholder="name@example.com">
    <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>




<div >
  

  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">telefono</label>
  </div>  <input type="number" class="form-control" value="<?php echo e($pr->prof_telefono); ?>" name="telefono" placeholder="telefono">
    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div >
  
  <div class="mt-3 ">
    <label for="exampleFormControlInput1" class="form-label">Email address</label>
   </div> <input type="email" value="<?php echo e($pr->prof_email); ?>" class="form-control" name="email" placeholder="name@example.com">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
</div>

<div class="d-grid gap-2 mt-3">
  <button type="submit" class="btn btn-primary">Editar</button>
  <a href ="<?php echo e(route('dash_admin')); ?>"  class="btn btn-danger" >VOLVER</a> 
 </div>


  </form>




    </div>
  </div>

</div>

<script>
  function ShowSelected()
  {
  /* Para obtener el valor */
  var esp_value = document.getElementById("especialidad").value;
   
  /* Para obtener el texto */
  var combo = document.getElementById("especialidad");
  var selected = combo.options[combo.selectedIndex].text;
   
  document.getElementsByName("esp")[0].value = selected;
  document.getElementsByName("id_esp")[0].value = esp_value;
	
  }
  </script>
<?php echo $__env->make('layouts.admin.pacientes.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\profesionales\editar.blade.php ENDPATH**/ ?>