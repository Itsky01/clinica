

<?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\livewire\resumenturno.blade.php ENDPATH**/ ?>