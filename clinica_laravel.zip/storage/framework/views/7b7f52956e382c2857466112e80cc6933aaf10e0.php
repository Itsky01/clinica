<!-- Button trigger modal -->

  
  <!-- Modal -->
  <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
   
    <form action="" method="post" id="frm">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
   
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title " id="staticBackdropLabel">Borrar registro</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
    ¿Confirma la eliminacion de este registro?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">CANCELAR</button>
          <button type="submit" class="btn btn-primary delete">SI</button>
        </div>
      </div>
    </div>
 
</form>
</div>
<?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\profesionales\modal_delete.blade.php ENDPATH**/ ?>