

 
<div>
 
 <script src="https://code.jquery.com/jquery-3.5.1.js"></script>  
  
    <?php echo $__env->make('layouts.styles_dtables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>  
  
    #tablefecha_filter{ display: none; }
  
  </style>

   

     <?php echo \Livewire\Livewire::styles(); ?>

     <div class="container-fluid">
        <h5 class="bg-primary text-center p-4 text-white">Cargar fechas de atencion</h1>
       
         <div class="card text-center mt-3">
           <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="card-header border shadow-sm">
     Para seleccionar mas de 1 fecha, mantenga presionada la tecla CTRL + CLICK
          </div> 
          <div class="card-body shadow">
            <form action ="<?php echo e(route('creafechas')); ?>" method="post" >
           <?php echo csrf_field(); ?>
            <div class="container"> 
 
<div class="row justify-content-md-center">

  <div class="col-12 col-lg-5 pt-2">

  <div class="form-group" id="divprof">
   
              

    
       
  <?php $__errorArgs = ['profesional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   
   </div> </div> </div>




   <div class="row justify-content-md-center">
       <div class="col-12 col-lg-5 pt-2">
          <?php if(!is_null($contarfechas)): ?>
               <div class="form-group">  
                <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
                <input type="hidden" name="idprof" id="idprof" value="<?php echo e($valor); ?>">      
                <table class="table table-hover display responsive nowrap" id="tablefecha">
                

<thead>
  <tr>
<th scope="col">Dia</th>
<th scope="col">Fecha</th>
<th scope="col"></th>
</tr>
</thead>

<tbody>
<?php $__currentLoopData = $listarfecha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th><?php if($dato->dias_id=='1'): ?> Lunes
  <?php else: ?> <?php if($dato->dias_id =='2'): ?> Martes
   <?php else: ?> <?php if($dato->dias_id =='3'): ?> Miercoles
   <?php else: ?> <?php if($dato->dias_id =='4'): ?> Jueves
   <?php else: ?> <?php if($dato->dias_id =='5'): ?> Viernes
   <?php endif; ?>
    <?php endif; ?>  <?php endif; ?> <?php endif; ?> <?php endif; ?>

   </th>
  
<th><?php echo e(date('d-m-y', strtotime($dato->fecha))); ?></th>
<th>
<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#staticBackdrop" wire:click="deletefecha(<?php echo e($dato->f_id); ?>)" >Delete</button>
 </th>
</tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</tbody>



  </table>
 
              </div> 

               <?php else: ?> <p class="text-center p-5"> Sin fechas cargadas</p>
              
              <?php endif; ?>
               <?php echo $__env->make('layouts.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              
              </div> </div> </div>

<hr>
 
              <div class="row justify-content-md-center">  
          <div class="col-12 col-lg-6">
          
                              <div class="form-group" id="divprof">
                      <label for="my-select">dias de atencion</label>
                                
                
                      <select wire:model='selecteddia' <?php echo e((!empty($diaprof)) ? '' : 'disabled'); ?>  class="form-select" wire:loading.attr="disabled" id="day" name="day" required>
                           
                        <?php if(!is_null($diaprof)): ?>
                        
                    <option value="0" selected >Seleccione Dia</option>
                       <?php $__currentLoopData = $diaprof; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dias_atencion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
                        <option value="<?php echo e($dias_atencion->d_id); ?>" <?php if($dias_atencion->id == $dias_atencion->d_id): ?> selected <?php endif; ?>><?php echo e($dias_atencion->dia); ?></option>
                      
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                      
                      <?php else: ?>

                      <option value="0" selected >Sin dias disponibles</option> 
                      
                        <?php endif; ?>


                        
                    </select> 
                         
                    <?php $__errorArgs = ['day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     
                     </div> 
                 
                    </div>
                              
       
                 
            </div>


          
            
            <div class="container pt-5">
  <div class="row row-cols-1 row-cols-lg-3 g-2 g-lg-3">
    <div class="col">
      
      <label for="my-select">Fechas de atencion</label>
             
      <select multiple class="form-select" id="eligefecha" name="eligefecha" <?php echo e((!empty($startdate)) ? '' : 'disabled'); ?>  >
   
       <?php if(!is_null($startdate)): ?>
     
      <option value="" disabled>Seleccione Fecha</option>
      <?php while($startdate < $enddate): ?> 

     <option value="<?php echo e(date('Y-m-d', $startdate)); ?>"><?php echo e(date("d/m/y", $startdate)); ?></option>
         
     <?php echo e($startdate = strtotime("+1 week", $startdate)); ?>

                   
     <?php endwhile; ?>
     <?php else: ?>

<option value="" disabled>SIN FECHAS DISPONIBLES</option>
   <?php endif; ?>
   </select>

  
   
<?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   
    </div>




    <div class="col pt-3">
      <div class="d-grid gap-4 col-6 col-lg-4 mx-auto">
        <input type="button" value="seleccionar" id="btnfecha" onclick="seleccionar()" <?php echo e((!empty($startdate)) ? '' : 'disabled'); ?> class="" >
        <input type="button" value="Quitar" id="btnpasarfecha" onclick="quitar()" <?php echo e((!empty($startdate)) ? '' : 'disabled'); ?>>
     
   
   
      </div>
   
   
    </div>
   
    <div class="col">


      <label for="my-select">Las fechas a cargar son:</label>
                  

      <div class="form-group">
      
      <select multiple id="fecha" class="form-control" <?php echo e((!empty($startdate)) ? '' : 'disabled'); ?> name="fecha[]" wire:model='pfecha' >
      
      
      </select>

      <?php $__errorArgs = ['eligefecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


      
    </div>
    <div class="col">
    
    </div>
    <div class="col">
      
    </div>
    
    
   
    
  </div>
</div>
            

          </div>

         
          </div>
          <div class="card-footer shadow bg-light border">
           Las fechas a cargar contemplan desde hoy hasta 6 semanas de anticipacion <hr>  
            <div class="d-grid gap-2 col-lg-5 mx-auto mt-4 " >
           
              <button type="submit" class="btn btn-primary ">Save changes</button>
          
              <a class="btn btn-danger text-white" href ="<?php echo e(route('dash_admin')); ?>"  role="button"> Volver</a>
          
            
              <div wire:loading wire:target="Confirmar" class="text-center" >
              <h4>Procesando informacion...</h4>
          </div>
            </div> 

                 </div> 
      </div>
     
           
           
            
          
        
        
   
   </form>
     
   
       
  
    <div class="modal fade" wire:ignore.self class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" >
  
    <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header bg-danger text-white">
            <h5 class="modal-title " id="staticBackdropLabel">Borrar profesional</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
           <div class="modal-body">
                <p>Are you sure want to delete?</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">CANCELAR</button>
            
            <button type="button" wire:click.prevent="delete(<?php echo e($valor); ?>)"  class="btn btn-danger close-modal" data-dismiss="modal">Yes, Delete</button>
                   
          </div>
        </div>
    </div>
</div>
</div>

 
    <?php echo \Livewire\Livewire::scripts(); ?>

      
   
<script>

$(document).ready( function () {
  $('#tablefecha').DataTable(
    { language: {
      
        
      }}  
    
    )
        }); 

        window.livewire.on('postUpdated', () => { // para ocultar modal al confirmar
            $('#staticBackdrop').modal('hide');
        });
   
 // siempre detener el submit
function seleccionar (){
 
  const ids = [...$("#eligefecha:selected")].map(e => e.value);
  $('#eligefecha option:selected').appendTo('#fecha').attr("value");

var mifecha= $('#fecha').val();
Livewire.emit('mifecha');

  $('#confirmar').prop('disabled',false);

  // $('#fecha option]').map(e => e.value).append('@');
 //  $("#pais option[value=2]").attr("selected",true);
  //alert(ids)
  
      }
     
      function quitar (){
  const id = [...$("#fecha:selected")].map(e => e.value);
  $('#fecha option:selected').appendTo('#eligefecha');
  //$('#fecha option:selected').appendTo('#fecha');
  // $('#fecha option]').map(e => e.value).append('@');
 //  $("#pais option[value=2]").attr("selected",true);
  //alert(ids)
      }

      
     </script>

   
       
 
     



<?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\livewire\cargarfechas.blade.php ENDPATH**/ ?>