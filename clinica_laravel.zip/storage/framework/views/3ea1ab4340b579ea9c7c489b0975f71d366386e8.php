
        
  
    <div class="container-fluid">
      <h5 class="bg-primary text-center p-4 text-white">Solicitud de consulta</h1>
       <?php echo \Livewire\Livewire::styles(); ?>

      <form action="<?php echo e(route('consulta')); ?>" method="post" >
     <?php echo csrf_field(); ?>
        <div class="card text-center mt-3">
         <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card-header border shadow-sm">
      <h5>  Solicite su consulta desplegando los selectores</h5>
        </div> 
        <div class="card-body shadow">
         
         
          <div class="container"> 
            <div class="row gy-3">
            
      
              <div class="col-12 col-lg-6 ">
        
    
    
                <div class="form-group" >            
                        <label for="my-select">Especialidad</label>
             
                 <select class="form-select" wire:model='esp' wire:loading.attr="disabled" aria-label="Default select example" id="especialidad" onchange="showesp()">
                  <option selected value="">Seleccione especialidad medica</option>
                             
                  <?php $__currentLoopData = $especialidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($especial->esp_id); ?>"><?php echo e($especial->esp_nombre); ?></option>
         
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
                </select>
    
                   
                </div>
             </div>
    
    
     
              
        <div class="col-12 col-lg-6">
        
                            <div class="form-group" id="divprof">
                    <label for="my-select">Profesionales disponibles</label>
                                  
              
                        <select wire:model='selectedprofesional' <?php echo e((!empty($profesionales)) ? '' : 'disabled'); ?> wire:loading.attr="disabled" class="form-select" id="tipo" name="tipo" onchange="showprof()">
                                             
                        <?php if(!is_null($profesionales)): ?>
                       <option value="" selected>Seleccione Profesional</option>
                        <?php $__currentLoopData = $profesionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($profesion->prof_id); ?>"><?php echo e($profesion->prof_nombre.' '.$profesion->prof_apellido); ?></option>
                      
                      
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php endif; ?>
                    </select> 

                   
                   </div> 
               
                  </div>
             
                  
                <div class="col-12 col-lg-6">
                    <div class="form-group" id="divfecha">
                     
                      
                         <label for="my-select">Fechas disponibles</label>
                  
                        <select wire:model='selectedfecha' <?php echo e((!empty($fechas)) ? '' : 'disabled'); ?> wire:loading.attr="disabled" class="form-select" id="fecha" name="fecha" onchange="showfecha()">
                       
                        <?php if(!is_null($fechas)&& !empty($divfechas)): ?>
                      
                       <option value="">Seleccione Fecha</option>
                        <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option data-valor="<?php echo e($fech->f_id); ?>" data-texto="<?php echo e($fech->fecha); ?>" value="<?php echo e($fech->profesionales_id); ?>"><?php echo e(date('d-m-y', strtotime($fech->fecha))); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                   


                        
                      
 <?php else: ?>
 
   <option value="" selected disabled>SIN FECHAS DISPONIBLES</option>
                  
                  
                      
                 
                  <?php endif; ?> </select>
                    </div>
           
    
                  </div> 
    
   
           
                <div class="col-12 col-lg-6">
                    <div class="form-group" id="divhora" >
                        <label for="my-select">Horarios disponibles</label>
                        <select id="hora" name="hora" <?php echo e((!empty($horarios)) ? '' : 'disabled'); ?>  wire:model="selectedhora" wire:loading.attr="disabled" class="form-select" onchange="showhora()" >
                           
                            <?php if(!is_null($horarios)&& !empty($divhoras)): ?>
                           <option value="" >Seleccione horarios</option>
                         
                           <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hora->hora_atencion); ?>"><?php echo e(date("H:i",(strtotime($hora->hora_atencion)))); ?></option>
                                                 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php else: ?>


<option value="" selected disabled>SIN HORARIOS DISPONIBLES</option>
   

                        <?php endif; ?>
                       
                        </select>
                        <?php $__errorArgs = ['hora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
            
                  </div>
               
                          
                   
                    <div class="col-12 pt-2" >
 <label for="form-check-input" >Medio de pago</label> &nbsp&nbsp&nbsp

                    <div class="form-check form-check-inline" > 
            
                        <input class="form-check-input "  <?php echo e(($btncontinuar==true) ? '' : 'disabled'); ?> type="radio" name="radio" id="radiouno" value="Particular" onclick="check()">
            <label class="form-check-label" for="inlineCheckbox1">Particular</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input"  <?php echo e(($btncontinuar==true) ? '' : 'disabled'); ?> type="radio" name="radio" id="radiodos" value="Mutual" onclick="check()">
            <label class="form-check-label" for="inlineCheckbox2">Mutual</label>
          </div>  <?php $__errorArgs = ['radio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
     
               
          </div>
              
        </div>
         
        </div>
       
    </div>
   
         
      <div class="row justify-content-md-center "> 
          <div class="col-md-8 pt-2">
            <div class="card-header border text-center text-white bg-primary">
                <h5 class="p-2">Resumen del turno</h5> 
                 </div>
              <div class="card p-3 shadow">
                
                  <label class="text-uppercase">Paciente</label>
                
                    <?php echo csrf_field(); ?>
                   
                  <div class="inputbox "> 
                    <?php if( Auth::user()->rol == '2' ): ?>
                    
                    <input type="text" name="paciente" value=" <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->apellido); ?>" class="form-control" required readonly>  </div>
                
                <?php else: ?>
                <input type="text" name="paciente" value=" <?php echo e(Auth::user()->apellido); ?>" class="form-control" required readonly>  </div>
              
<?php endif; ?>
                  <div class="row mt-3">
                      <div class="col-md-6">
                          <label class="text-uppercase">Profesional</label>
                          <div class="inputbox  mr-2"> <input type="text" name="nameprof" id="nameprof"class="form-control" required="required" readonly> <i class="fa fa-credit-card"></i> </div>
                      </div>
                      <div class="col-md-6 mt-3 mt-md-0">
                          <label class="text-uppercase">Especialidad</label>
                          <div class="inputbox mr-2"> <input type="text" name="esp" class="form-control" required="required" readonly>  </div>
                                              
                      </div>
                  </div>
                  <div class="mt-3">
                     
                      <div class="row ">
                          <div class="col-md-6">
                             <label for="mname">Medio pago</label>
                              <div class="inputbox mr-2"> <input type="text" name="txtradio" id="txtradio" class="form-control" required="required" readonly> </div>
                              
                            </div>
                        
                          <div class="col-md-6 mt-3 mt-md-0 ">
                              
                              <div class="d-flex flex-row ">  
                                  <div class="inputbox mr-2 "> <label for="fname">Fecha</label><input type="text" name="txtfecha" id="txtfecha" class="form-control" required="required"  readonly></div>
                              
                                  <div class="inputbox mr-2"> <label for="name">Hora</label><input type="text" name="txthora" id="txthora" class="form-control" required="required" readonly>  </div>
                                                        </div>
                                                        <?php $__errorArgs = ['txtfecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <?php $__errorArgs = ['txthora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                      </div>
                      <div class="d-grid gap-2 col-lg-8 mx-auto mt-4 " >
                          <button class="btn btn-primary text-white" <?php echo e((!empty($profesionales)) && (!empty($fechas)) && (!empty($horarios)) &&($btncontinuar==true) ? '' : 'disabled'); ?> type="submit" wire:loading.attr="disabled" wire:click='Confirmar' >Confirmar</button>
                          <a class="btn btn-danger text-white"  <?php echo e(($btnsubmit==false) ? '' : 'disabled'); ?> href ="<?php echo e(route('nuevo_turno')); ?>"  role="button"> Volver</a>
                      
                        
                          <div wire:loading wire:target="Confirmar" class="text-center" >
                          <h4>Procesando informacion...</h4>
                      </div>
                        </div>
                       
                                                
                  </div> 
                
                  <input type="text" class="form-control text-white d-none"  name="fech" id="fech" readonly>
                  <input type="text" class="form-control text-white d-none"  name="hidtxtfecha" id="hidtxtfecha" readonly>
                  <?php $__errorArgs = ['hidtxtfecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
              </div>
           
              
          </div>
          </form>
      </div>
      
  </div>
   
 
  <?php echo \Livewire\Livewire::scripts(); ?>

    
  <script src="<?php echo e(asset('js/funciones_turno.js')); ?>"></script>
   <?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\livewire\crearturno.blade.php ENDPATH**/ ?>