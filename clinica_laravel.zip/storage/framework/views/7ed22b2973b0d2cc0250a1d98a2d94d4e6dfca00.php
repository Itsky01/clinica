
 
<?php $__env->startSection('css'); ?>   <!-- abrimos section para agregar css de datatable solo para esta vista -->

    <?php echo $__env->make('layouts.styles_dtables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
   <?php echo $__env->make('navbar.nav-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="py-12 px-5">
  <h2 class="bg-primary text-center p-3 text-white shadow mt-3">Listado de Pacientes</h2>
 
           <?php $__env->startSection('contenido'); ?>
       
             
           <?php $__env->startSection('botones'); ?>
           <a href ="<?php echo e(route('crear_pac')); ?>"  class="btn btn-primary " >CREAR</a>
       
         <a href ="<?php echo e(route('dash_admin')); ?>"  class="btn btn-danger " >VOLVER</a>
       
       <?php $__env->stopSection(); ?>
       
              <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 <table class="table table-bordered display responsive nowrap" id="profesionales" style="width:100%">
                    <thead class="bg-info text-white">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellido</th>
                        <th scope="col">Documento</th>

                        <th scope="col">telefono</th>
                        <th scope="col">Domicilio</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">email</th>

<th></th>
<th></th>
<th></th>


                      </tr>
                    </thead>
                    <tbody>
 <?php $__currentLoopData = $usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th><?php echo e($dato->id); ?></th>
<th><?php echo e($dato->name); ?></th>
<th><?php echo e($dato->apellido); ?></th>
<th><?php echo e($dato->dni); ?></th>
<th><?php echo e($dato->telefono); ?></th>
<th><?php echo e($dato->domicilio); ?></th>
<th><?php echo e(date('d-m-y', strtotime($dato->fecha))); ?></th>
<th><?php echo e($dato->email); ?></th>
<!-- action=" {route('eliminar', $dato->id) }}
  {route('editar', $dato->id)}}
  " -->

<td><button type="submit" class="btn btn-primary text-white"><i class="bi bi-unlock"></i></button></td>
<td><button type="submit" class="btn btn-success"><i class="bi bi-calendar-check"></i></button></td>
<td><a class="btn btn-danger delete " id="btn" data-bs-toggle="modal" data-bs-target="#staticBackdrop" data-id="<?php echo e(route('eliminar', $dato->id)); ?>">
  <i class="bi bi-trash"></i>
  </a>
</td>


</tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
                 
                  </table>
                  <?php $__env->stopSection(); ?>

                  
                  <?php echo $__env->make('layouts.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('js'); ?>

<script>
$(document).ready( function () {
  $('#profesionales').DataTable(
    { language: {
        searchPlaceholder: "Buscar registros",
        search: "",
        
      }
     
    })
  
  
} 

    
    
    
    );
// paso ruta del form al modal
    $(document).on('click','.delete',function(){
        var data_url = $(this).attr('data-id');
        $('#frm').attr('action', data_url);

       
    });


</script>
    
<?php $__env->stopSection(); ?>
            
    </div>

    <?php echo $__env->make('layouts.admin.pacientes.modal_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.admin.pacientes.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\pacientes\pacientes.blade.php ENDPATH**/ ?>