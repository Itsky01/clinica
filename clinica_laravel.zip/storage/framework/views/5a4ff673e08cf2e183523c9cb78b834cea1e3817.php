
 
 <?php $__env->startSection('css'); ?>   <!-- abrimos section para agregar css de datatable solo para esta vista -->
 
     <?php echo $__env->make('layouts.styles_dtables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->stopSection(); ?>
    <?php echo $__env->make('navbar.nav-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <div class="px-5">
   
            <?php $__env->startSection('contenido'); ?>
           
         
 <h2 class="text-center bg-secondary text-white p-4"> LISTADO DE ESPECIALIDADES</h2>
 
 <div class="row d-flex justify-content-center ">
  <div class="col-sm-7 col-md-5">
  <form action="<?php echo e(route('nuevaEsp')); ?>" method="post">
    <?php echo csrf_field(); ?>
 <div class="input-group mt-3">
 
  <input type="text" class="form-control" placeholder="Ingrese nueva especialidad" id="nombre" name="nombre" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
  <button class="btn btn-primary" type="submit" >Cargar</button>

  
</div>
      </form>      
  </div> </div>


  <div class="input-group my-4 mx-auto">
                 
                  
                    <a href ="<?php echo e(route('dash_admin')); ?>"  class="btn btn-secondary " >VOLVER</a>  </div>
                
                <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <table class="table table-bordered display responsive nowrap" id="esp" style="width:100%">
                     <thead class="bg-primary text-white text-center">
                       <tr>
                        
                         <th scope="col">Denominacion</th>
                         
                                               <th></th>
 
 
 
 
                       </tr>
                     </thead>
                     <tbody class="text-center">
  <?php $__currentLoopData = $esp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
 
 <th><?php echo e($dato->esp_nombre); ?></th>
  
 <form action="" method="post" >
 <?php echo csrf_field(); ?>
 <?php echo method_field('DELETE'); ?>
 
 <td><a class="btn btn-danger delete" id="btn" data-bs-toggle="modal" data-bs-target="#staticBackdrop" data-id="<?php echo e(route('eliminar_esp', $dato->esp_id)); ?>">
  <i class="bi bi-trash"></i>
</a> </td>
 
 </form>
 </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
                  
                   </table>
                   <?php $__env->stopSection(); ?>


                                    
                  
                   <?php echo $__env->make('layouts.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



 <?php $__env->startSection('js'); ?>
 
 <script>
 $(document).ready( function () {
   $('#esp').DataTable(
     { language: {
         searchPlaceholder: "Buscar registros",
         search: "",
         
       }
      
     })
   
   
 } );
   // paso ruta del form al modal
   $(document).on('click','.delete',function(){
        var data_url = $(this).attr('data-id');
        $('#frm').attr('action', data_url);

       
    });       
 </script>
      </div>
 <?php $__env->stopSection(); ?>
             
    
 
     <?php echo $__env->make('layouts.admin.profesionales.modal_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.admin.pacientes.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\especialidades\especialidades.blade.php ENDPATH**/ ?>