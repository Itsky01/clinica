<div>
 
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>  
     
       <?php echo $__env->make('layouts.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php if(Auth::user()->isAdmin()): ?>

<?php echo $__env->make('navbar.nav-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php else: ?>
 <?php echo $__env->make('navbar.nav-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?> 
    

<?php echo \Livewire\Livewire::styles(); ?>

<div class="py-12 px-5">
 
    <h2 class="bg-primary text-center p-3 text-white shadow mt-3">turnos pendientes</h2>
    <div class="container overflow-hidden p-5">
       <div class="row gx-5 ">
         <div class="col-12 col-md-6 mb-2 mb-md-0">
           <select class="form-select" aria-label="Default select example" wire:model='selectedprof' name="especialidad" id="especialidad" >
             <option selected disabled>Seleccione profesional</option>
             <?php $__currentLoopData = $profesionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
             <option value="<?php echo e($profesional->prof_id); ?>"><?php echo e($profesional->prof_nombre.' '.$profesional->prof_apellido); ?></option>
           
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
         </div>
         <div class="col-12 col-md-6">
           <select class="form-select" aria-label="Default select example" name="especialidad" id="especialidad" onchange="ShowSelected();">
             <option selected disabled>Seleccione fecha</option>
            </select>
         </div>
       </div>
     </div>
                          
   <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table class="table table-hover display responsive nowrap" style="width:100%" id="tableprof" wire:model='tablaturnos' <?php echo e((!empty($profesionales)) ? '' : 'disabled'); ?>>
                     <thead class="bg-primary text-white">
                         <tr>
                           <th scope="col">Paciente</th>
                           <th scope="col">Estudio</th>
                           <th scope="col">Profesional</th>
   
                           <th scope="col">Fecha</th>
                           <th scope="col">Hora</th>
   
                           <th scope="col">Medio de pago</th>
                          
   <th></th>
   
   
                         </tr>
                       </thead>
                                         
                       <tbody>
   
                        <?php if(!is_null($profesionales)): ?>
   
                        <?php $__currentLoopData = $turno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th><?php echo e($dato->apellido); ?> <?php echo e($dato->name); ?></th>
                        <th><?php echo e($dato->nombre_estudio); ?></th>
                        <th><?php echo e($dato->prof_apellido); ?> <?php echo e($dato->prof_nombre); ?></th>
                        <th> <?php echo e(date('d-m-y', strtotime($dato->est_fecha))); ?></th>
                        <th> <?php echo e(date('H:i', strtotime($dato->hora))); ?></th>
                        <th><?php echo e($dato->mediopago); ?></th>
                        
                        
                         
                        <td><a class="btn btn-danger delete" id="btn" data-bs-toggle="modal" data-bs-target="#staticBackdrop" data-id="<?php echo e(route('eliminar_prof', $dato->prof_id)); ?>">
                        
                          <i class="bi bi-trash3"></i>
                        </a> </td>
                        
                        
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
     </tbody>
                     
                     </table>
                     
                   

                    </div>
                   
                </div>        
     
     
     
     
<?php echo \Livewire\Livewire::scripts(); ?> 
                  
                     
                    
                    <script>
      $(document).ready( function () {
     $('#tableprof').DataTable(
       {
         
         dom: 'Bfertip',
                  
        
      
           
                    
                       buttons: [
   
         {
                   extend: 'print',
                   text: '<i class="bi bi-printer"></i>',
                   title: '', 
                   className: 'btn btn-info', //Primary class for all buttons
                    exportOptions: {
                       columns: ':visible',
                     
                   },
                    
               },
               
           {
                   extend: 'excelHtml5',
                   className: 'btn btn-success', //Primary class for all buttons
                   text: '<i class="bi bi-filetype-xlsx"></i>',
                   title: 'turnos pendientes',
                            exportOptions: {
                       columns: ':visible',
                     
                   },
               },
                    
           {
                   extend: 'pdfHtml5',
                   title: 'turnos pendientes',
                   text: '<i class="bi bi-filetype-pdf"></i>',
                   className: 'btn btn-danger ', //Primary class for all buttons
                   download: 'open',
                   exportOptions: {
                       columns: ':visible',
                     
                   },
               },
                {
                   extend: 'colvis',
                   text:'<i class="bi bi-columns "></i>',
                    className: 'btn btn-warning ', //Primary class for all buttons     
                       }
       ],
         
            language: {
           searchPlaceholder: "Buscar registros",
           search: "",
           
         }
        
       }
       )
     
     
   }); 
            // paso ruta del form al modal
       $(document).on('click','.delete',function(){
           var data_url = $(this).attr('data-id');
           $('#frm').attr('action', data_url);
   
          
       });         
                     </script>
                         
                           
          
       
   
                     <?php echo $__env->make('layouts.admin.profesionales.modal_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
   
   


























<?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\livewire\turnospendientes.blade.php ENDPATH**/ ?>