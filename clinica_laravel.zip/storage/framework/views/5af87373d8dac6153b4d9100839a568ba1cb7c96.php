
 
 <?php $__env->startSection('css'); ?>   <!-- abrimos section para agregar css de datatable solo para esta vista -->
 
     <?php echo $__env->make('layouts.styles_dtables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->stopSection(); ?>
    <?php echo $__env->make('navbar.nav-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <div class="px-5">
   
            <?php $__env->startSection('contenido'); ?>
           
         
 <h2 class="text-center bg-secondary text-white p-4"> Horarios de trabajo</h2>
 
 <div class="row d-flex justify-content-center ">
  <div class="col-sm-7 col-md-5">
  <form action="<?php echo e(route('nuevahora')); ?>" method="post">
    <?php echo csrf_field(); ?>
 <div class="input-group mt-3">
 
  <input type="time" class="form-control" placeholder="Ingrese nuevo horario" id="imphora" name="imphora" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
  <button class="btn btn-primary" type="submit" >Cargar nuevo horario</button>
 



</div>
 <?php $__errorArgs = ['imphora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </form>      
  </div> 


  <div class="input-group my-4 mx-auto">
                 
                  
                    <a href ="<?php echo e(route('dash_admin')); ?>"  class="btn btn-secondary " >VOLVER</a>  </div>
                
                <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="col-sm-7 col-md-8">
                  <table class="table table-bordered display responsive nowrap" id="esp" style="width:100%">
                     <thead class="bg-primary text-white text-center">
                       <tr>
                       
                         <th scope="col">Horario</th>
                         
                                               
                             <th></th>
 
                       </tr>
                     </thead>
                     <tbody class="text-center">
  <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
 
 <th><?php echo e($dato->horas_reloj); ?></th>
 
 <form action="" method="post" >
 <?php echo csrf_field(); ?>
 <?php echo method_field('DELETE'); ?>
 
 <td><a class="btn btn-danger delete" id="btn" data-bs-toggle="modal" data-bs-target="#staticBackdrop" data-id="<?php echo e(route('borra_hs', $dato->id_horas)); ?>">
  <i class="bi bi-trash"></i>
</a> </td>
 
 </form>
 </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
                  
                   </table> </div> </div>
                   <?php $__env->stopSection(); ?>


                                    
                  
                   <?php echo $__env->make('layouts.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



 <?php $__env->startSection('js'); ?>
 
 <script>
    // paso ruta del form al modal
   $(document).on('click','.delete',function(){
        var data_url = $(this).attr('data-id');
        $('#frm').attr('action', data_url);

       
    });       
 </script>
      </div>
 <?php $__env->stopSection(); ?>
             
    
 
     <?php echo $__env->make('layouts.admin.profesionales.modal_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('layouts.admin.pacientes.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\profesionales\horarios_centrales.blade.php ENDPATH**/ ?>