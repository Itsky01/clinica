<?php $__env->startSection('css'); ?>   <!-- abrimos section para agregar css de datatable solo para esta vista -->

<?php echo $__env->make('layouts.styles_dtables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->stopSection(); ?>
  
    <?php if(Auth::user()->isAdmin()): ?>

    <?php echo $__env->make('navbar.nav-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php else: ?>
     <?php echo $__env->make('navbar.nav-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php endif; ?>

 <div class="py-12 px-5">
 
 <h2 class="bg-primary text-center p-3 text-white shadow mt-3">LISTADO DE PROFESIONALES</h2>
  <?php $__env->startSection('contenido'); ?>
    
   
        
    <?php $__env->startSection('botones'); ?>
    <a href ="<?php echo e(route('crearpr')); ?>"  class="btn btn-primary " >CREAR</a>

  <a href ="<?php echo e(route('dash_admin')); ?>"  class="btn btn-danger " >VOLVER</a>

<?php $__env->stopSection(); ?>



 
             
                
                    
<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 <table class="table table-hover display responsive nowrap" style="width:100%" id="tableprof">
                  <thead class="bg-primary text-white">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellido</th>
                        <th scope="col">Especialidad</th>
                        <th scope="col">Documento</th>

                        <th scope="col">telefono</th>
                        <th scope="col">domicilio</th>
                         <th scope="col">email</th>
<th></th>
<th></th>
<th></th>
<th></th>

                      </tr>
                    </thead>
                    <tbody>
 <?php $__currentLoopData = $profesion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th><?php echo e($dato->prof_id); ?></th>
<th><?php echo e($dato->prof_nombre); ?></th>
<th><?php echo e($dato->prof_apellido); ?></th>
<th><?php echo e($dato->esp_nombre); ?></th>
<th><?php echo e($dato->prof_dni); ?></th>
<th><?php echo e($dato->prof_telefono); ?></th>
<th><?php echo e($dato->prof_domicilio); ?></th>
<th><?php echo e($dato->prof_email); ?></th>

 
<td><a href ="<?php echo e(route('editprof', $dato->prof_id)); ?>"  class="btn btn-info" ><i class="bi bi-pen"></i></a>   </td>
<td><a href ="<?php echo e(route('cargafechas', $dato->prof_id)); ?>"  class="btn btn-success" ><i class="bi bi-calendar-range"></i></a>   </td>
<td><a href ="<?php echo e(route('creahoras', $dato->prof_id)); ?>"  class="btn btn-warning" ><i class="bi bi-clock-history"></i></i></a>   </td>



<td><a class="btn btn-danger delete" id="btn" data-bs-toggle="modal" data-bs-target="#staticBackdrop" data-id="<?php echo e(route('eliminar_prof', $dato->prof_id)); ?>">

  <i class="bi bi-trash3"></i>
</a> </td>


</tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
                  
                  </table>
                  <?php $__env->stopSection(); ?>
                   <?php echo $__env->make('layouts.datatables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php $__env->startSection('js'); ?>
                  
                 
                 <script>
   $(document).ready( function () {
  $('#tableprof').DataTable(
    { language: {
        searchPlaceholder: "Buscar registros",
        search: "",
        
      }
     
    })
  
  
}); 
         // paso ruta del form al modal
    $(document).on('click','.delete',function(){
        var data_url = $(this).attr('data-id');
        $('#frm').attr('action', data_url);

       
    });         
                  </script>
                      
                  <?php $__env->stopSection(); ?>          </div>
       
    

                  <?php echo $__env->make('layouts.admin.profesionales.modal_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



 
<?php echo $__env->make('layouts.admin.pacientes.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\profesionales\profesionales.blade.php ENDPATH**/ ?>