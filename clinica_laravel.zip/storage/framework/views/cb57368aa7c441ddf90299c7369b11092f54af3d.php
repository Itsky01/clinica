

<div class="p-5 m-4 ">
  
  <div class="row border border-secondary p-3 rounded-3">
    <h2 class="p-2 bg-danger text-white text-center">Editar usuarios</h2>
  
    <form action="<?php echo e(route('edicion', $us->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
          
        
        <div class="col-sm col-md-9 ">
    <label for="exampleFormControlInput1" class="form-label">Apellido</label>
    <input type="text" class="form-control" id="apellido" name="apellido" value="<?php echo e($us->apellido); ?>" placeholder="Apellido">
   <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="col-sm col-md-9 ">
  

<div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">Nombre</label>
    <input type="text" value="<?php echo e($us->name); ?>" class="form-control" name="nombre" placeholder="Nombre">
  </div>
  <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>



<div class="col-sm col-md-9 ">
  

  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">documento</label>
  </div>  <input type="number" class="form-control" value="<?php echo e($us->dni); ?>" name="documento" placeholder="Documento">
 
 
    <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="col-sm col-md-9 ">
  

  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">domicilio</label>
  </div>  <input type="text" class="form-control"  value="<?php echo e($us->domicilio); ?>" name="domicilio" placeholder="name@example.com">
    <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>




<div class="col-sm col-md-9 ">
  

  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">telefono</label>
  </div>  <input type="number" class="form-control" value="<?php echo e($us->telefono); ?>" name="telefono" placeholder="telefono">
    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="col-sm col-md-9 ">
  

  <div class="mt-3">
    <label for="exampleFormControlInput1" class="form-label">Fecha de nacimiento</label>
   </div> <input type="date" class="form-control" value="<?php echo e($us->fecha); ?>" name="fecha" placeholder="fecha de nacimiento">
    <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="col-sm col-md-9 ">
  


  <div class="mt-3 ">
    <label for="exampleFormControlInput1" class="form-label">Email address</label>
   </div> <input type="email" value="<?php echo e($us->email); ?>" class="form-control" name="email" placeholder="name@example.com">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> <small> <?php echo e($message); ?> </small>  </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <div class="mt-3 ">
    <button type="submit" class="btn btn-primary">editar</button>
    <a href ="<?php echo e(route('pacientes')); ?>"  class="btn btn-danger" >VOLVER</a>  </div>
</form>

</div>




</div>


<?php echo $__env->make('pacientes.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clinica_laravel\resources\views\layouts\admin\pacientes\editar.blade.php ENDPATH**/ ?>