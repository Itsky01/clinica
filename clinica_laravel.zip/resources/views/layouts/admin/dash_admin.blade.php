@extends('layouts.admin.pacientes.plantillabase')
@include ('navbar.nav-user')