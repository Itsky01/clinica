<?php return array (
  'cargarfechas' => 'App\\Http\\Livewire\\Cargarfechas',
  'crearturno' => 'App\\Http\\Livewire\\Crearturno',
  'crearturnoestudio' => 'App\\Http\\Livewire\\Crearturnoestudio',
  'turnospendientes' => 'App\\Http\\Livewire\\Turnospendientes',
);